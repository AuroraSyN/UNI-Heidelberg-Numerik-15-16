// hallowelt.cc (Dateiname als Kommentar)
#include <iostream>  // notwendig zur Ausgabe

int main ()
{
  std::cout << "Numerik 0 ist leicht:" << std::endl;
  std::cout << "1+1=" << 1+1 << std::endl;
}
