// mehrzahlen.cc
#include <iostream> // header f�r Ein-/Ausgabe
#include <complex>  // header f�r komplexe Zahlen
int main ()
{
  std::complex<double> y(1.0,3.0);
  std::cout << y << std::endl;
}
